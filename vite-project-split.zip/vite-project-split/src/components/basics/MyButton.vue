<template>
    <!-- コンポーネントのルート要素が今回のように1つの場合 -->
    <!-- イベントリスナーを設定しなくても継承される -->
    <button class="my-btn">
    <!-- MyButtonコンポーネントを使用する際に中身を親コンポーネント側で設定できる仕組み。 -->
        <slot />
    </button>
</template>

<style>
.my-btn {
    color: #fff;
    background-color: #333;
    margin-left: 0.5em;
    border-radius: 0.5em;
}
</style>